package gotcha;

import processing.core.PApplet;

@SuppressWarnings("serial")
public class Gotcha_skeleton extends PApplet {
  // Keep track of ball's x and y coordinates
  // Here we initialize the starting position
  float x = 300;
  float y = 250;
  
  // Keep track of current score, start with 0 points
  int score = 0;
  
  // Horizontal speed - start with a slow speed like 2
  float xSpeed = 2;
  
  // Canvas size
  final int canvasWidth  = 500;
  final int canvasHeight = 500;
  
  // Shape size
  final int shapeWidth  = 80;
  final int shapeHeight = 50;
  
  // It's hard to click a precise position, to make it easier, 
  // require the click to be somewhere on the shape
  int targetRange = Math.round((min(shapeWidth, shapeHeight)) / 2);

  // Shape value
  int pointValue = 10;
  
  // Setup runs one time at the beginning of your program
  public void setup() {
    System.out.println("targetRange: " + targetRange);
    size(canvasWidth, canvasHeight);
    smooth();
  }

  // Draw is called in an infinite loop.
  // By default, it is called about 60 times per second.
  public void draw() {
    // Erase the background, if you don't, the previous shape will 
    // still be displayed
    eraseBackground();
    
    // Move the shape, i.e. calculate the next x and y position
    // where the shape will be drawn.
    calcCoords();

    // Draw the shape
    drawShape();
    
    // Display point value on the shape
    displayPointValue();
    
    // Display player's score
    //TODO:
  }

  // mousePressed is a PApplet method that you can override.
  // This method is designed to be called one time when the mouse is pressed
  public void mousePressed() {
    // Draw a circle wherever the mouse is
    int mouseWidth  = 20;
    int mouseHeight = 20;
    fill(0, 255, 0);
    ellipse(this.mouseX, this.mouseY, mouseWidth, mouseHeight);
    
    // Check whether the click occurred within range of the shape
    //TODO: Did the player click on the shape? 
    //TODO: If so, increase their score.
  }
  
  public void eraseBackground() {
    background(255);
  }
  
  public void calcCoords() {      
    // Compute the x position where the shape will be drawn
    this.x += this.xSpeed; 

    // If the x position is off the canvas, reverse direction of 
    // movement
    if (this.x > canvasWidth) {
      System.out.println("<===  Change direction, go left because x = " + x);
      this.xSpeed = -1 * this.xSpeed;
    }

    // If the x position is off the canvas, reverse direction of 
    // movement
    if (this.x < 0) {
      System.out.println("     ===> Change direction, go right because x = " + x + "\n");
      this.xSpeed = -1 * this.xSpeed;
    } 
  }

  public void drawShape() {
    // Select color, then draw the shape at computed x, y location
    //TODO: Add fill color
    ellipse(this.x, this.y, shapeWidth, shapeHeight);
  }
  
  public void displayPointValue() {
    // Draw the text at computed x, y location
    //TODO:
  }
}
